<?php

namespace Drupal\taxonomy_tree\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\taxonomy\Entity\Term;

/**
 * Class for Get started form.
 */
class GetStartedFormUs extends ControllerBase {

  /**
   * Handled the state Request with desc.
   */
  public function sendRequestDesc() {

    $country_id =  $_POST['country_id'];
 //echo '<pre>';print_r($states_id);exit;
    $tt = \Drupal::service('taxonomy_tree.taxonomy_term_tree');
    $tree = $tt->load('country');
       //  $state_tree = [];
    //  $data = '';
    foreach ($tree as $tree_item) {
      $country_tree[$tree_item->tid] = $tree_item->name;
      
    if($country_id == $tree_item->tid){
      if(!empty($tree_item->children)){
        $data = '';
      
        foreach ($tree_item->children as $child_item){
          //if($states_id == $child_item->tid){
          $state_id = $child_item->tid;
         // echo '<pre>';print_r($child_item);
          $state_name = '<span class ="state">'.$child_item->name.'</span>';
          $term = \Drupal\taxonomy\Entity\Term::load($state_id);
          $Exclamation_Circle =   $term->get('field_exclamation_circle')->value;
         //  if($Exclamation_Circle == 1){
         //    $description = '<span class="description exclamation-circle">'.$child_item->description__value.'</span>';
         //  }else{
         //    $description = '<span  class ="description" >'.$child_item->description__value.'</span>';
         //  }
         $description = '<span  class ="description" >'.$child_item->description__value.'</span>';
          if($Exclamation_Circle == 1){
            $data .=  '<div class ="state-container exclamation-circle ">'.$state_name .''.$description.'</div>';
          }else{
            $data .=  '<div class ="state-container">'.$state_name .''.$description.'</div>';
          }
         
          
       // }
      }
      //exit;
      }
    }
   }   
   
     $result = json_encode(['data'=>$data,'descritpion'=>$description,'exclamation_circle'=>$Exclamation_Circle]);
     echo $result;
     exit;
   }



}
