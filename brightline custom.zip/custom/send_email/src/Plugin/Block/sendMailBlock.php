<?php

namespace Drupal\send_email\Plugin\Block;

use Drupal\Core\Form\FormInterface;
use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'send mail' block.
 *
 * @Block(
 *   id = "sendMail_block",
 *   admin_label = @Translation("sendMail block"),
 *   category = @Translation("Custom sendMail block example")
 * )
 */
class sendMailBlock extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {  
      $form = \Drupal::formBuilder()->getForm('Drupal\send_email\Form\sendEmailForm');  
      return $form;
     }
  }