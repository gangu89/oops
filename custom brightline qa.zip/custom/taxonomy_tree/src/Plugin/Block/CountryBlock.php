<?php

namespace Drupal\taxonomy_tree\Plugin\Block;

use Drupal\Core\Form\FormInterface;
use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'CountryBlock' block.
 *
 * @Block(
 *   id = "country_block",
 *   admin_label = @Translation("Country block"),
 *   category = @Translation("Custom Country block example")
 * )
 */
class CountryBlock extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {  
      $form = \Drupal::formBuilder()->getForm('Drupal\taxonomy_tree\Form\CountryForm');  
      return $form;
     }
  }