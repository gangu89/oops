jQuery(document).ready(function(){
	jQuery(".sendemailtoreferee").click(function(event) {
		//alert(2);
		event.preventDefault();
		var data_arr = [];
		var key = '';
		jQuery(this).closest( "tr" ).find('td').each(function(k,v){
				data_arr.push(jQuery(this).text());
		});

		key = jQuery(this).attr('rowid');//console.log('this is key---'+key);
		var d_arr = {};
		d_arr['nodeidform'] = jQuery('#nodeidform-'+key).val();
		d_arr['sidform'] = jQuery('#sidform-'+key).val();
		//d_arr['orgscore'] = jQuery('#orgscore-'+key).val();//console.log('score is --'+d_arr['orgscore']);

		data_arr.push(d_arr);
	           //console.log(data_arr);

		if(data_arr.length > 0){
                   //alert(2);
			//var oid_val = jQuery('#oid-'+key).val();
                                         // alert(oid_val);
			jQuery.ajax({
				type:'POST',
				url:Drupal.settings.basePath+'sendemailtoreferee/ajax',
				data: {data_arr:data_arr},
				success:function(result) {
					var a = result.split('::');
				 	var test1 = a[0];
				 	var key = a[5];
                                        
					//jQuery('#datadisplayorg-'+key).html(test1);			
					//jQuery('#avg-'+key).html(a[6]);
				}
			});
                        	         //  console.log(data_arr);

		}
		
	});
});









