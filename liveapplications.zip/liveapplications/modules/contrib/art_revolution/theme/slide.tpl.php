<li<?php print $attributes;?>>
	<?php print $content;?>
</li>