    <p><?php print render($intro_text); ?></p>
    <div class="yourtheme-user-login-form-wrapper">
      <?php print drupal_render_children($form) ?>
    </div>
