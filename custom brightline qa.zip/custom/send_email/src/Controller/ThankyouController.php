<?php
namespace Drupal\send_email\Controller;
 
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Database\Database;
 
/**
 * Provides route responses for the Example module.
 */
class ThankyouController extends ControllerBase {
 
  /**
   * Returns a simple page.
   *
   * @return array
   *   A simple renderable array.
   */
  public function successpage() {
  //display thankyou page
    $element = array(
      '#markup' => 'Form data submitted',
    );
    return $element;
  }
 
  public function getDetails() {
  //fetch data from employee table.
  $db = \Drupal::database(); 
  $query = $db->select('send_email', 'mail'); 
  $query->fields('mail'); 
  $response = $query->execute()->fetchAll();
    return [
      '#theme' => 'user_list_table',
      '#content' => $response,
    ];
  }
}