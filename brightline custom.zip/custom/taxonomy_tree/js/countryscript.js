(function ($, Drupal) {
	'use strict';
//Document ready function
var $current_item = 0;
var description = '';
$(document).ready(function () {

$('#state_desc_card').css('display','none');
	$('#country_id').on('select2:open', function (e) {
        let val =  $(this).val();
            if(!!val) {
              $(this).val('').trigger('change.select2');
            }
		});
		
	$('#country_id').on('change', function(){


		var countryID = $(this).val();
		// alert(countryID);
		$("#country_id").select2({
			placeholder: "Choose a state",
			allowClear: true
		});
		$.ajax({
			url: drupalSettings.path.baseUrl + "get-started-us/send-request-state",
			type: "post",
			data: 'country_id='+countryID,
			success: function (result) {
				var obj = $.parseJSON(result);
		   console.log(result);
			 if(obj.data === null){
			//	$('#country-name-des').text('');
							$('#states_description').text('');							
							$('#state_desc_card').removeClass('bck-grey');						
								// $('#states_description').removeClass('exclamation-circle');
							//	$('#states_description').text('');
								$('#states_description').append('There are no active or planned grade crossing closures in this county code.')	
						
			
			}else{				
				$('#states_description').html(obj.data);				
			}
        this.description = obj.description;
				check_state_description(obj.descritpion);		

      }
      });

		
		setTimeout(function(){
			if($('#country_id option:selected').text() != ''){
				
				$('#state_desc_card').css('display','block');
				var conceptName = $('#country_id :selected').text();
				//alert(conceptName);
						if(conceptName == '---'){
							$('#country-name-des').text('');
							$('#states_description').text('');
							$('#states_description').removeClass('exclamation-circle');	
		          $('#state_desc_card').removeClass('bck-grey');	
							// $('#country-name-des').text($('#country_id option:selected').text());
						}else{							
							$('#country-name-des').text($('#country_id option:selected').text());
						}

			}else{
			
			}
                         if($('#country_id').has('option').length == 0){	
				$('#country-name-des').text('');
			}

		   }, 10);
	});	

	// console.log(countryID);
	$("#country_id").select2({
		placeholder: "Choose a State",
		allowClear: true
	});

});


$('#country_id').on('select2:close', function (e) {
	var data = e.params.data;
	if(typeof data == 'undefined'){
		//$('#states_id').text('');
		$('#states_description').text('');
		$('#country-name-des').text('');
		$('#states_description').removeClass('exclamation-circle');	
		$('#state_desc_card').removeClass('bck-grey');
		$('#state_desc_card').hide();		
	}
 });



function check_state_description(desc){
  if(desc){
    $('#state_desc_card').addClass('bck-grey');
    //$('#states_description').addClass('exclamation-circle');
  }else{
    $('#state_desc_card').removeClass('bck-grey');
    //$('#states_description').removeClass('exclamation-circle');

  }
}


})(jQuery, Drupal);



