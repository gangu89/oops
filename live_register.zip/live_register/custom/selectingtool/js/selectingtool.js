jQuery(document).ready(function(){
	jQuery(".updateorgpreselection").click(function(event) {
		//alert(2);
		event.preventDefault();
		var data_arr = [];
		var key = '';
		jQuery(this).closest( "tr" ).find('td').each(function(k,v){
				data_arr.push(jQuery(this).text());
		});

		key = jQuery(this).attr('rowid');//console.log('this is key---'+key);
		//console.log(key);
		var d_arr = {};
		d_arr['orgcode'] = jQuery('#orgcode-'+key).val();
		d_arr['orgcomment'] = jQuery('#orgcombine-'+key).val();
		d_arr['orgscore'] = jQuery('#orgscore-'+key).val();//console.log('score is --'+d_arr['orgscore']);

		data_arr.push(d_arr);

		//console.log(data_arr);
		if(data_arr.length > 0){
			var oid_val = jQuery('#oid-'+key).val();
                        //console.log(oid_val);
			jQuery.ajax({
				type:'POST',
				url:Drupal.settings.basePath+'preselection/ajax',
				data: {data_arr:data_arr,oid:oid_val,key:key},
				success:function(result) {
					console.log(result);
					// body...
					var a = result.split('::');
					//console.log(a);
				 	var test1 = a[0];
                                       // console.log(test1);
				 	var key = a[5];
                                        
					jQuery('#datadisplayorg-'+key).html(test1);
				//	jQuery('#orgcode-'+key).val(a[1]).change();
				//	jQuery('#orgcombine-'+key).val(a[2]);
			//		jQuery('#orgscore-'+key).val(a[3]).change();
		//			jQuery('#oid-'+key).val(a[4]);
	//				jQuery('#orgcode-'+key+' option[value="'+a[1]+'"]').attr("selected", "selected");
					jQuery('#avg-'+key).html(a[6]);
				}
			});
		}
		//console.log(data_arr);
		// $('#orgcombine-'+key).val('');
		 //$('#orgcode-'+key).prop('selectedIndex',0);
		 //$('#orgscore-'+key).prop('selectedIndex',0);

	});
});
jQuery(document).ready(function(){
	jQuery(".updateorgpreselected").click(function(event) {
		//alert(2);
		event.preventDefault();
		var data_arr = [];
		var key = '';
		jQuery(this).closest( "tr" ).find('td').each(function(k,v){
				data_arr.push(jQuery(this).text());
		});

		key = jQuery(this).attr('rowid');//console.log('this is key---'+key);
		//console.log(key);
		var d_arr = {};
		d_arr['orgcode'] = jQuery('#orgcode-'+key).val();
		d_arr['orgcomment'] = jQuery('#orgcombine-'+key).val();
		d_arr['orgscore'] = jQuery('#orgscore-'+key).val();//console.log('score is --'+data_arr['orgscore']);
		d_arr['uid'] = jQuery('#uid-'+key).val();//console.log('score is --'+data_arr['orgscore']);

		data_arr.push(d_arr);

	//console.log(data_arr);
		if(data_arr.length > 0){
			var oid_val = jQuery('#oid-'+key).val();
			jQuery.ajax({
				type:'POST',
				url:Drupal.settings.basePath+'preselected/ajax',
				data: {data_arr:data_arr,oid:oid_val,key:key},
				success:function(result) {
//if(result.success == true){ // if true (1)
					     /* setTimeout(function(){// wait for 2 secs(2)
						   location.reload(); // then reload the page.(3)
					      }, 2000); */
					   //}
					console.log(result);
					// body...
					var a = result.split('::');
					//console.log(a);
				 	var test1 = a[0];
//console.log(a[2]);
				 	var key = a[5];
					jQuery('#datadisplayorg-'+key).html(test1);
					jQuery('#orgcode-'+key).val(a[1]).change();
					jQuery('#orgcombine-'+key).val(a[2]);
					jQuery('#orgscore-'+key).val(a[3]).change();
					jQuery('#oid-'+key).val(a[4]);
					jQuery('#orgcode-'+key+' option[value="'+a[1]+'"]').attr("selected", "selected");
					

				}
			});
		}
		//console.log(data_arr);
		// $('#orgcombine-'+key).val('');
		 //$('#orgcode-'+key).prop('selectedIndex',0);
		 //$('#orgscore-'+key).prop('selectedIndex',0);

	});
});








