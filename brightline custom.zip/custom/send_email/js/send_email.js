(function ($, Drupal) {
  Drupal.behaviors.form_submit_processor = {
    attach: function (context, settings) {
      $("form#send-email-form").submit(function(e) {
        $("#send_mail_sucessMessage").css("display", "block");
        setTimeout(function () {
          $('#send_mail_form').remove();
        }, 0);        
        $('.alert-success').css('display','none');
      });
    }
  }
})(jQuery, Drupal);
