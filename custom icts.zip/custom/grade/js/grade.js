jQuery(document).ready(function() {
				

				//ICTS Institute code
				jQuery("#edit-field-institute-und").change(function () {
				var institute = jQuery('#edit-field-institute-und option:selected').text();

				jQuery.ajax({
				type:'POST',
				url:Drupal.settings.basePath+'actual_grade/ajax',
				data: {institute:institute},
				success:function(result) {
				jQuery('#edit-field-actual-grade-und').empty();
				console.log(result);
				var jsonData = jQuery.parseJSON(result);
				var select = jQuery('#edit-field-actual-grade-und');
				var None_option = jQuery("<option/>").attr("value", '').text('--None--');
				select.append(None_option);
				jQuery(jsonData).each(function (index, o) {    
				var option = jQuery("<option/>").attr("value", o).text(o);
				select.append(option);
				});
				}
			});

				jQuery('#edit-field-renormalized-grade-und-0-value').val('');
				jQuery('#edit-field-actual-marks-und-0-value').val('');
				jQuery('#edit-field-renormalized-marks-und-0-value').val('');
				if (institute == "ICTS"){
				    jQuery('#edit-field-actual-marks-und-0-value').attr('readonly',false);
				    jQuery('#edit-field-renormalized-marks-und-0-value').attr('readonly',true);
				}else if (institute == "IISC"){
				    jQuery('#edit-field-actual-marks-und-0-value').attr('readonly',true);
				    jQuery('#edit-field-renormalized-marks-und-0-value').attr('readonly',true);
				}



		});
		
		//IISC Institute code
				jQuery("#edit-field-actual-grade-und").change(function () {
				var institute = jQuery('#edit-field-institute-und option:selected').text();
				var renormalized_actual_grade = jQuery('#edit-field-actual-grade-und option:selected').text();
				//alert(rinstitute);
				jQuery.ajax({
				type:'POST',
				url:Drupal.settings.basePath+'renormalized_grade/ajax',
				data: {institute:institute,renormalized_actual_grade:renormalized_actual_grade},
				success:function(result) {
				jQuery('#edit-field-renormalized-grade-und-0-value').empty();
				console.log(result);
				var renormalized_grade_marks = jQuery.parseJSON(result);
				jQuery('#edit-field-renormalized-grade-und-0-value').attr('readonly', true);
				jQuery('#edit-field-renormalized-grade-und-0-value').val(renormalized_grade_marks.rcode);
				jQuery('#edit-field-renormalized-marks-und-0-value').val(renormalized_grade_marks.rmarks)
				
				}
			});

		});
		//text 
		jQuery('#edit-field-actual-marks-und-0-value').keyup(function() {
			//alert(jQuery(this).val()); 
			jQuery('#edit-field-renormalized-marks-und-0-value').val(jQuery(this).val());
		    });     

} );


/*jQuery(document).ready(function(){


				//by defacult Renormalized Grade readonly
				jQuery('#edit-field-renormalized-grade-und-0-value').attr('readonly', true);
				
				jQuery("#edit-field-institute-und").change(function () {
				var institute = jQuery('#edit-field-institute-und option:selected').text();
				var institute_name = this.value.toUpperCase();
				
				jQuery('#edit-field-actual-marks-und-0-value').attr("value", "");
				jQuery('#edit-field-renormalized-marks-und-0-value').attr("value", "");
				if(institute_name == 'ICTS'){
				
					jQuery("#edit-field-actual-marks-und-0-value").keyup(function(){
						var actual_marks=this.value;
						jQuery('#edit-field-renormalized-marks-und-0-value').val(actual_marks);
					jQuery('#edit-field-renormalized-marks-und-0-value').attr('readonly', true);

					  });



				}
				else if(institute_name == 'IISC'){
alert(institute_name);
					jQuery('#edit-field-actual-marks-und-0-value').attr('readonly', true);
				}

});


});*/


