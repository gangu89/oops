<?php

namespace Drupal\export_excel\Controller;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\image\Entity\ImageStyle;
use Drupal\Component\Utility\Html;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Datetime\DrupalDateTime;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\Core\Url;
use Drupal\Core\Routing;
use Drupal\Core\Field\EntityReferenceFieldItemList;
use Drupal\node\Entity\Node;


/**
 * Controller to update Scheme Funds Content.
 */
class GetListEmail extends ControllerBase
{
  /**
   * {@inheritdoc}
   */
  protected $entityTypeManager;
  /**
   * {@inheritdoc}
   */
  protected $cacheBackend;
  /**
   * {@inheritdoc}
   */
  protected $entityQuery;

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager, CacheBackendInterface $cacheBackend, QueryFactory $entityQuery)
  {
    $this->entityTypeManager = $entityTypeManager;
    $this->cacheBackend = $cacheBackend;
    $this->entityQuery = $entityQuery;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container)
  {
    return new static(
      $container->get('entity.manager'),
      $container->get('cache.default'),
      $container->get('entity.query')
    );
  }

  public function Getmails()
  {
  	$database = \Drupal::database();
    $query = $database->query("SELECT * FROM {send_email}");
    $result = $query->fetchAll();

$num_results = count($result);
if($num_results > 0){
    $delimiter = ",";
    $filename = "members_" . date('Y-m-d') . ".csv";
    
    //create a file pointer
    $f = fopen('php://memory', 'w');
    
    //set column headers
    $fields = array('PID', 'Email', 'Roles');
    fputcsv($f, $fields, $delimiter);
    
    //output each row of the data, format line as csv and write to file pointer    
      foreach($result as $v){
       // $status = ($row['status'] == '1')?'Active':'Inactive';
        $lineData = array($v->pid, $v->email,$v->role);
        fputcsv($f, $lineData, $delimiter);
    }
    
    //move back to beginning of file
    fseek($f, 0);
    
    //set headers to download file rather than displayed
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '";');
    
    //output all remaining data on a file pointer
    fpassthru($f);
}
exit;
    echo "...File is ok";die;  
  }
}
