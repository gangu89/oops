jQuery(document).ready(function(){
    
jQuery("#edit-select-all").on("change", function () {   
	jQuery('.form-checkbox').attr('checked', this.checked);
      
       /* jQuery(".form-checkbox").click(function(){

	alert("You have checked  "+jQuery(".form-checkbox:checked").length+"  boxes");

	if($(".form-checkbox").length == jQuery(".form-checkbox:checked").length) {

	jQuery("#edit-select-all").attr("checked", "checked");

	} else {

	jQuery("#edit-select-all").removeAttr("checked");

	}
});*/
      //https://www.sanwebe.com/2014/01/how-to-select-all-deselect-checkboxes-jquery
      //http://www.infotuts.com/easy-way-to-select-deselect-checkboxes-jquery/
    

});
});
