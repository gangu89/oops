
  <?php
/*echo '<pre>';
print_r($user_profile['profile_main']['view']
		['profile2'][1]['field_first_name']
		['#object']->field_first_name['und'][0]['value']);
exit;*/
global $user;
					$profile = profile2_load_by_user($user->uid, $type_name = 'main') ;
//echo '<pre>';print_r($profile);exit;
?>

<div id="user-profile">
   
  </div>
  
  <table style="width:50%">
  <tr><b>Basic Information</b></tr>
  <tr>
    <td style="width:50%;">First Name</td>

    <td><?php 
	if(!empty($profile->field_first_name_profile['und'][0]['value']))	
{
	print $profile->field_first_name_profile['und'][0]['value'];
}	
?></td>    
  </tr>
<tr>
    <td style="width:50%;">Middle Name</td>
    <td><?php
if(!empty($profile->field_middle_name['und'][0]['value']))	
{
	print $profile->field_middle_name['und'][0]['value'];
}
		 ?></td>    
  </tr>
<tr>
    <td style="width:50%;">Last Name</td>
    <td>
		<?php
	   if(!empty($profile->field_last_name_profile['und'][0]['value'])){

		echo $profile->field_last_name_profile['und'][0]['value']; 
	   }
		 ?></td>    
  </tr>
  <tr>
    <td style="width:50%;">Email Id</td>
    <td><?php
if(!empty($profile->field_email_id_profile['und'][0]['value'])){
	print $profile->field_email_id_profile['und'][0]['value']; 
}
		 ?></td>    
  </tr>
    <tr>
    <td style="width:50%;">Gender</td>
    <td><?php if(!empty($profile->field_gender['und'][0]['value'])){
	print $profile->field_gender['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
    <tr>
    <td style="width:50%;">Nationality</td>
    <td><?php if(!empty($profile->field_nationality['und'][0]['value'])){
					$country_profile = $profile->field_nationality['und'][0]['value']; // Example, return "TR"
					$country_nationality = get_country_name_by_code_profile($country_profile);
					
					print $country_nationality; 
	}
		 ?></td>    
  </tr>
</table> 

<table style="width:50%">
  <tr><b>Institutional Information</b></tr>
  <tr>
    <td style="width:50%;">Current Status</td>

    <td><?php 
	if(!empty($profile->field_current_status['und'][0]['value'])){
	print $profile->field_current_status['und'][0]['value'];
	}
		
?></td>    
  </tr>
<tr>
    <td style="width:50%;">Department</td>
    <td><?php
if(!empty($profile->field_department['und'][0]['value'])){
	print $profile->field_department['und'][0]['value'];
}
		 ?></td>    
  </tr>
<tr>
    <td style="width:50%;">Institute Name</td>
    <td><?php
if(!empty($profile->field_institute_name['und'][0]['value'])){
	print $profile->field_institute_name['und'][0]['value']; 
}
		 ?></td>    
  </tr>
  <tr>
    <td style="width:50%;">Institute Address Line 1</td>
    <td><?php 
	if(!empty($profile->field_institute_address_line_1['und'][0]['value'])){
		print $profile->field_institute_address_line_1['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
   <tr>
    <td style="width:50%;">Institute Address Line 2</td>
    <td><?php 
	if(!empty($profile->field_institute_address_line_2['und'][0]['value'])){
		print $profile->field_institute_address_line_2['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
   <tr>
    <td style="width:50%;">Institute Address Line 3</td>
    <td><?php 
	if(!empty($profile->field_institute_address_line_3['und'][0]['value'])){
	print $profile->field_institute_address_line_3['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
    <tr>
    <td style="width:50%;">City</td>
    <td><?php 
	if(!empty($profile->field_city['und'][0]['value'])){
			print $profile->field_city['und'][0]['value'];
	}
		 ?></td>    
  </tr>
    <tr>
    <td style="width:50%;">Institute Country</td>
    <td><?php if(!empty($profile->field_institute_country['und'][0]['value'])){
					$country_iso_institute = $profile->field_institute_country['und'][0]['value']; // Example, return "TR"
					$country_institute = get_country_name_by_code_profile($country_iso_institute);
					print $country_institute; 
	}
		 ?></td>    
  </tr>
    <tr>
    <td style="width:50%;">Postal Code</td>
    <td><?php 
	if(!empty($profile->field_postal_code['und'][0]['value'])){
	print $profile->field_postal_code['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
</table> 
<?php
//echo $country_nationality.'>>>>'.$country_institute;exit;
if($country_nationality!='India' && $country_institute !='India'){
if(!empty($profile->field_passport_information['und'][0]['value'])){
$passport =$profile->field_passport_information['und'][0]['value'];
//$field_collection_passport = entity_load('field_collection_item',array($passport));
$entity = field_collection_item_load($passport);
   //echo '<pre>';print_r($entity);exit;
}
 ?>
 
 <?php/*************************Personal Details passport**********************/ ?>
 <table style="width:50%">
  <tr><b>Personal Details</b></tr>
  <tr>
    <td style="width:50%;">Date of Birth</td>

    <td><?php 
	if(!empty($entity->field_date_of_birth['und'][0]['value'])){
	$date_date_of_birth=date_create($entity->field_date_of_birth['und'][0]['value']);
		$passport_date= date_format($date_date_of_birth,"Y-m-d");
		print $passport_date;
	}
		
?></td>    
  </tr>
<tr>
    <td style="width:50%;">Place of Birth </td>
    <td><?php 
	if(!empty($entity->field_place_of_birth['und'][0]['value'])){
		print $entity->field_place_of_birth['und'][0]['value'];
	}
		 ?></td>    
  </tr>
<tr>
    <td style="width:50%;">Residential Address Line 1 </td>
    <td><?php
if(!empty($entity->field_residential_address_line_1['und'][0]['value'])){
	print $entity->field_residential_address_line_1['und'][0]['value']; 
}
		 ?></td>    
  </tr>
  <tr>
    <td style="width:50%;">Residential Address Line 2 </td>
    <td><?php if(!empty($entity->field_residential_address_line_2['und'][0]['value'])){
	print $entity->field_residential_address_line_2['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
   <tr>
    <td style="width:50%;">Residential Address Line 3 </td>
    <td><?php if(!empty($entity->field_residential_address_line_3['und'][0]['value'])){
		print $entity->field_residential_address_line_3['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
   <tr>
    <td style="width:50%;">City</td>
    <td><?php if(!empty($entity->field_city_passport['und'][0]['value'])){
		print $entity->field_city_passport['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
    <tr>
    <td style="width:50%;">Father's Name </td>
    <td><?php if(!empty($entity->field_father_s_name['und'][0]['value'])){
		print $entity->field_father_s_name['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
   <tr>
    <td style="width:50%;">Mother's Name </td>
    <td><?php
if(!empty($entity->field_mother_s_name['und'][0]['value'])){
	print $entity->field_mother_s_name['und'][0]['value']; 
}
		 ?></td>    
  </tr>
    <tr>
    <td style="width:50%;">Institute Country</td>
    <td><?php if(!empty($entity->field_institute_country['und'][0]['value'])){
					$country_iso_institute_passport = $entity->field_institute_country['und'][0]['value']; // Example, return "TR"
					$country_institute_passport = get_country_name_by_code_profile($country_iso_institute_passport);
					print $country_institute_passport; 
	}
		 ?></td>    
  </tr>
    <tr>
    <td style="width:50%;">Postal Code</td>
    <td><?php 
	if(!empty($entity->field_postal_code['und'][0]['value'])){
	print $entity->field_postal_code['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
</table>
 <?php /******************************/?>
 
 <?php/************************* Passport Details passport**********************/ ?>
 <table style="width:50%">
  <tr><b>Passport Details</b></tr>
  <tr>
    <td style="width:50%;">Passport Number </td>

    <td><?php if(!empty($entity->field_passport_number['und'][0]['value'])){
	print $entity->field_passport_number['und'][0]['value'];
	}
		
?></td>    
  </tr>
<tr>
    <td style="width:50%;">Date of Issue </td>
    <td><?php 
	if(!empty($entity->field_date_of_issue['und'][0]['value'])){
		$date_of_issue=date_create($entity->field_date_of_issue['und'][0]['value']);
		$passport_date_of_issue= date_format($date_of_issue,"Y-m-d");
		print $passport_date_of_issue;
	}
		 ?></td>    
  </tr>
<tr>
    <td style="width:50%;">Place of Issue  </td>
    <td><?php if(!empty($entity->field_place_of_issue['und'][0]['value'])){
		print $entity->field_place_of_issue['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
  <tr>
    <td style="width:50%;">Date of Expiry </td>
    <td><?php 
if(!empty($entity->field_date_of_expiry['und'][0]['value'])){
	$date_of_expiry=date_create($entity->field_date_of_expiry['und'][0]['value']);
		$passport_date_of_expiry= date_format($date_of_expiry,"Y-m-d");
		print $passport_date_of_expiry;
}
		 ?></td>    
  </tr>
   <tr>
    <td style="width:50%;">indian Consulate where visa application will be made </td>
    <td><?php
	if(!empty($entity->field_indian_consulate_where_vis['und'][0]['value'])){
	print $entity->field_indian_consulate_where_vis['und'][0]['value']; 
	}
		}//end if condtion ?></td>    
  </tr>
  
</table>
 <?php /******************************/?>
<table  border="1" cellpadding="1" cellspacing="1" style="width:100%;">
 <tr><b>Academic Information</b></tr>
<tr>
	<td style="width:100px;"><strong>Degree</strong></td>
	<td style="width:70px;"><strong>Year of Passing</strong></td>
	<td style="width:50px;"><strong>University/Bodrd</strong></td>
	<td style="width:50px;"><strong>Subjects</strong></td>
        <td style="width:50px;"><strong>Percentage/Marks/Grade</strong></td>
</tr>			
<?php 
//dsm ($user_profile['profile_main']['view']['profile2'][49]['field_academic_information']['#object']);
	$kvalue = NULL;
	foreach($user_profile['profile_main']['view']['profile2'] as $k=>$v){
	$kvalue=$k;
	}
if(!empty($user_profile['profile_main']['view']['profile2'][$kvalue]['field_academic_information']['#object']->field_academic_information['und'])){
foreach ($user_profile['profile_main']['view']['profile2'][$kvalue]
        ['field_academic_information']['#object']->field_academic_information['und'] as $key => $value) {
	$field_collection = entity_load('field_collection_item',array($value['value'])); 
	$idx = $value['value']; 
?> 
<tr>
	<td><?php print isset($field_collection[$idx]->field_degree['und'][0]['value'])?$field_collection[$idx]->field_degree['und'][0]['value']:NULL;?></td>
	<td><?php print isset($field_collection[$idx]->field_year_of_passing['und'][0]['value'])?$field_collection[$idx]->field_year_of_passing['und'][0]['value']:NULL; ?></td>
	<td><?php print isset($field_collection[$idx]->field_university_bodrd['und'][0]['value'])?$field_collection[$idx]->field_university_bodrd['und'][0]['value']:NULL; ?></td>
	<td><?php print isset($field_collection[$idx]->field_subjects['und'][0]['value'])?$field_collection[$idx]->field_subjects['und'][0]['value']:NULL; ?></td>
    <td><?php print isset($field_collection[$idx]->field_percentage_marks_grade['und'][0]['value'])?$field_collection[$idx]->field_percentage_marks_grade['und'][0]['value']:NULL; ?></td>
<?php 	
} }?>	
</tr>

</table>

<table style="width:50%">
  <tr><b>Research Interests</b></tr>
  <tr>
    <td style="width:50%;">Research Interests</td>

    <td><?php 
	if(!empty($profile->field_research_interests['und'][0]['value'])){
	print $profile->field_research_interests['und'][0]['value'];
	}
		
?></td>    
  </tr>
<tr>
    <td style="width:50%;">Link</td>
    <td><?php
if(!empty($profile->field_link['und'][0]['value'])){
	print $profile->field_link['und'][0]['value'];
}
		 ?></td>    
  </tr>
<tr>
    <td style="width:50%;">Upload</td>
    <td><?php if(!empty($profile->field_upload['und'][0]['uri'])){
	$file_path = file_create_url($profile->field_upload['und'][0]['uri']);	
	$accountname_file= $profile->field_upload['und'][0]['filename']; 
	print "<a href='".$file_path."'>".$accountname_file."</a>";
	}?></td>    
  </tr>
</table> 

<table style="width:50%">
  <tr><b>References</b></tr>
  <tr>
    <td style="width:50%;">Salutation</td>

    <td><?php if(!empty($profile->field_salutation['und'][0]['value'])){
	print $profile->field_salutation['und'][0]['value'];
	}
		
?></td>    
  </tr>
<tr>
    <td style="width:50%;">Referee Name</td>
    <td><?php if(!empty($profile->field_referee_name['und'][0]['value'])){
		print $profile->field_referee_name['und'][0]['value'];
	}
		 ?></td>    
  </tr>
<tr>
    <td style="width:50%;">Affiliation</td>
    <td><?php if(!empty($profile->field_affiliation_profile['und'][0]['value'])){
	print $profile->field_affiliation_profile['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
  <tr>
    <td style="width:50%;">Email Id Referee</td>
    <td><?php if(!empty($profile->field_email_id_referee['und'][0]['value'])){
	print $profile->field_email_id_referee['und'][0]['value']; 
	}
		 ?></td>    
  </tr>
</table> 
<table style="width:50%">
  <tr><b>Please Upload Your CV </b></tr>
 
<tr>
    <td style="width:50%;">Please Upload Your CV </td>
    <td><?php if(!empty($profile->field_please_upload_your_cv['und'][0]['uri'])){
	$file_path_cv = file_create_url($profile->field_please_upload_your_cv['und'][0]['uri']);	
	$cv_account_file=$profile->field_please_upload_your_cv['und'][0]['filename'];
	print "<a href='".$file_path_cv."'>".$cv_account_file."</a>";
	
	} ?></td>    
  </tr>

 
</table> 
<table style="width:50%">
  <tr><b>User picture </b></tr>
 
<tr>
    <td style="width:50%;">User Picture </td>

    <td>

<?php if ($logged_in): ?>
            <?php 
                $user = user_load($user->uid);
                if($user->picture){
                print theme_image_style(
                array(
                    'style_name' => 'thumbnail',
                    'path' => $user->picture->uri,
                    'attributes' => array(
                                        'class' => 'avatar'
                                    )            
                    )
                ); 
                }else{
                    echo '<img src="replace with path to your default picture" />';
                }       
            ?>
<?php endif; ?>


</td>     
  </tr>

 
</table> 

<?php 
/**
 * Get country name by country code.
 *
 * @return string on success, boolean false otherwise
 */
function get_country_name_by_code_profile( $country_code ) {
    $countries = array(
        'AX' => 'Åland Islands',
        'AF' => 'Afghanistan',
        'AL' => 'Albania',
        'DZ' => 'Algeria',
        'AD' => 'Andorra',
        'AO' => 'Angola',
        'AI' => 'Anguilla',
        'AQ' => 'Antarctica',
        'AG' => 'Antigua and Barbuda',
        'AR' => 'Argentina',
        'AM' => 'Armenia',
        'AW' => 'Aruba',
        'AU' => 'Australia',
        'AT' => 'Austria',
        'AZ' => 'Azerbaijan',
        'BS' => 'Bahamas',
        'BH' => 'Bahrain',
        'BD' => 'Bangladesh',
        'BB' => 'Barbados',
        'BY' => 'Belarus',
        'PW' => 'Belau',
        'BE' => 'Belgium',
        'BZ' => 'Belize',
        'BJ' => 'Benin',
        'BM' => 'Bermuda',
        'BT' => 'Bhutan',
        'BO' => 'Bolivia',
        'BQ' => 'Bonaire, Saint Eustatius and Saba',
        'BA' => 'Bosnia and Herzegovina',
        'BW' => 'Botswana',
        'BV' => 'Bouvet Island',
        'BR' => 'Brazil',
        'IO' => 'British Indian Ocean Territory',
        'VG' => 'British Virgin Islands',
        'BN' => 'Brunei',
        'BG' => 'Bulgaria',
        'BF' => 'Burkina Faso',
        'BI' => 'Burundi',
        'KH' => 'Cambodia',
        'CM' => 'Cameroon',
        'CA' => 'Canada',
        'CV' => 'Cape Verde',
        'KY' => 'Cayman Islands',
        'CF' => 'Central African Republic',
        'TD' => 'Chad',
        'CL' => 'Chile',
        'CN' => 'China',
        'CX' => 'Christmas Island',
        'CC' => 'Cocos (Keeling) Islands',
        'CO' => 'Colombia',
        'KM' => 'Comoros',
        'CG' => 'Congo (Brazzaville)',
        'CD' => 'Congo (Kinshasa)',
        'CK' => 'Cook Islands',
        'CR' => 'Costa Rica',
        'HR' => 'Croatia',
        'CU' => 'Cuba',
        'CW' => 'CuraÇao',
        'CY' => 'Cyprus',
        'CZ' => 'Czech Republic',
        'DK' => 'Denmark',
        'DJ' => 'Djibouti',
        'DM' => 'Dominica',
        'DO' => 'Dominican Republic',
        'EC' => 'Ecuador',
        'EG' => 'Egypt',
        'SV' => 'El Salvador',
        'GQ' => 'Equatorial Guinea',
        'ER' => 'Eritrea',
        'EE' => 'Estonia',
        'ET' => 'Ethiopia',
        'FK' => 'Falkland Islands',
        'FO' => 'Faroe Islands',
        'FJ' => 'Fiji',
        'FI' => 'Finland',
        'FR' => 'France',
        'GF' => 'French Guiana',
        'PF' => 'French Polynesia',
        'TF' => 'French Southern Territories',
        'GA' => 'Gabon',
        'GM' => 'Gambia',
        'GE' => 'Georgia',
        'DE' => 'Germany',
        'GH' => 'Ghana',
        'GI' => 'Gibraltar',
        'GR' => 'Greece',
        'GL' => 'Greenland',
        'GD' => 'Grenada',
        'GP' => 'Guadeloupe',
        'GT' => 'Guatemala',
        'GG' => 'Guernsey',
        'GN' => 'Guinea',
        'GW' => 'Guinea-Bissau',
        'GY' => 'Guyana',
        'HT' => 'Haiti',
        'HM' => 'Heard Island and McDonald Islands',
        'HN' => 'Honduras',
        'HK' => 'Hong Kong',
        'HU' => 'Hungary',
        'IS' => 'Iceland',
        'IN' => 'India',
        'ID' => 'Indonesia',
        'IR' => 'Iran',
        'IQ' => 'Iraq',
        'IM' => 'Isle of Man',
        'IL' => 'Israel',
        'IT' => 'Italy',
        'CI' => 'Ivory Coast',
        'JM' => 'Jamaica',
        'JP' => 'Japan',
        'JE' => 'Jersey',
        'JO' => 'Jordan',
        'KZ' => 'Kazakhstan',
        'KE' => 'Kenya',
        'KI' => 'Kiribati',
        'KW' => 'Kuwait',
        'KG' => 'Kyrgyzstan',
        'LA' => 'Laos',
        'LV' => 'Latvia',
        'LB' => 'Lebanon',
        'LS' => 'Lesotho',
        'LR' => 'Liberia',
        'LY' => 'Libya',
        'LI' => 'Liechtenstein',
        'LT' => 'Lithuania',
        'LU' => 'Luxembourg',
        'MO' => 'Macao S.A.R., China',
        'MK' => 'Macedonia',
        'MG' => 'Madagascar',
        'MW' => 'Malawi',
        'MY' => 'Malaysia',
        'MV' => 'Maldives',
        'ML' => 'Mali',
        'MT' => 'Malta',
        'MH' => 'Marshall Islands',
        'MQ' => 'Martinique',
        'MR' => 'Mauritania',
        'MU' => 'Mauritius',
        'YT' => 'Mayotte',
        'MX' => 'Mexico',
        'FM' => 'Micronesia',
        'MD' => 'Moldova',
        'MC' => 'Monaco',
        'MN' => 'Mongolia',
        'ME' => 'Montenegro',
        'MS' => 'Montserrat',
        'MA' => 'Morocco',
        'MZ' => 'Mozambique',
        'MM' => 'Myanmar',
        'NA' => 'Namibia',
        'NR' => 'Nauru',
        'NP' => 'Nepal',
        'NL' => 'Netherlands',
        'AN' => 'Netherlands Antilles',
        'NC' => 'New Caledonia',
        'NZ' => 'New Zealand',
        'NI' => 'Nicaragua',
        'NE' => 'Niger',
        'NG' => 'Nigeria',
        'NU' => 'Niue',
        'NF' => 'Norfolk Island',
        'KP' => 'North Korea',
        'NO' => 'Norway',
        'OM' => 'Oman',
        'PK' => 'Pakistan',
        'PS' => 'Palestinian Territory',
        'PA' => 'Panama',
        'PG' => 'Papua New Guinea',
        'PY' => 'Paraguay',
        'PE' => 'Peru',
        'PH' => 'Philippines',
        'PN' => 'Pitcairn',
        'PL' => 'Poland',
        'PT' => 'Portugal',
        'QA' => 'Qatar',
        'IE' => 'Republic of Ireland',
        'RE' => 'Reunion',
        'RO' => 'Romania',
        'RU' => 'Russia',
        'RW' => 'Rwanda',
        'ST' => 'São Tomé and Príncipe',
        'BL' => 'Saint Barthélemy',
        'SH' => 'Saint Helena',
        'KN' => 'Saint Kitts and Nevis',
        'LC' => 'Saint Lucia',
        'SX' => 'Saint Martin (Dutch part)',
        'MF' => 'Saint Martin (French part)',
        'PM' => 'Saint Pierre and Miquelon',
        'VC' => 'Saint Vincent and the Grenadines',
        'SM' => 'San Marino',
        'SA' => 'Saudi Arabia',
        'SN' => 'Senegal',
        'RS' => 'Serbia',
        'SC' => 'Seychelles',
        'SL' => 'Sierra Leone',
        'SG' => 'Singapore',
        'SK' => 'Slovakia',
        'SI' => 'Slovenia',
        'SB' => 'Solomon Islands',
        'SO' => 'Somalia',
        'ZA' => 'South Africa',
        'GS' => 'South Georgia/Sandwich Islands',
        'KR' => 'South Korea',
        'SS' => 'South Sudan',
        'ES' => 'Spain',
        'LK' => 'Sri Lanka',
        'SD' => 'Sudan',
        'SR' => 'Suriname',
        'SJ' => 'Svalbard and Jan Mayen',
        'SZ' => 'Swaziland',
        'SE' => 'Sweden',
        'CH' => 'Switzerland',
        'SY' => 'Syria',
        'TW' => 'Taiwan',
        'TJ' => 'Tajikistan',
        'TZ' => 'Tanzania',
        'TH' => 'Thailand',
        'TL' => 'Timor-Leste',
        'TG' => 'Togo',
        'TK' => 'Tokelau',
        'TO' => 'Tonga',
        'TT' => 'Trinidad and Tobago',
        'TN' => 'Tunisia',
        'TR' => 'Turkey',
        'TM' => 'Turkmenistan',
        'TC' => 'Turks and Caicos Islands',
        'TV' => 'Tuvalu',
        'UG' => 'Uganda',
        'UA' => 'Ukraine',
        'AE' => 'United Arab Emirates',
        'GB' => 'United Kingdom (UK)',
        'US' => 'United States (US)',
        'UY' => 'Uruguay',
        'UZ' => 'Uzbekistan',
        'VU' => 'Vanuatu',
        'VA' => 'Vatican',
        'VE' => 'Venezuela',
        'VN' => 'Vietnam',
        'WF' => 'Wallis and Futuna',
        'EH' => 'Western Sahara',
        'WS' => 'Western Samoa',
        'YE' => 'Yemen',
        'ZM' => 'Zambia',
        'ZW' => 'Zimbabwe',
    );
 
    if ( isset( $countries[ $country_code ] ) ) 
	return $countries[ $country_code ] ;
	else 
	 //$country_code;
    return $country_code;
}



	   ?>
