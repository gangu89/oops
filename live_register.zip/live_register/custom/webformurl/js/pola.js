jQuery(document).ready(function(){
	jQuery(".updateorg").click(function(event) {
	//	alert(2);
		event.preventDefault();
		var data_arr = [];
		var key = '';
		$(this).closest( "tr" ).find('td').each(function(k,v){
				data_arr.push($(this).text());
		});

		key = $(this).attr('rowid');//console.log('this is key---'+key);
		
		var d_arr = {};
		d_arr['orgcode'] = $('#orgcode-'+key).val();
		d_arr['orgcomment'] = $('#orgcombine-'+key).val();
		d_arr['orgscore'] = $('#orgscore-'+key).val();//console.log('score is --'+data_arr['orgscore']);

		data_arr.push(d_arr);

		//console.log(data_arr);
		if(data_arr.length > 0){
			var oid_val = $('#oid-'+key).val();
			$.ajax({
				type:'POST',
				url:Drupal.settings.basePath+'webformurl/organize/ajax',
				data: {data_arr:data_arr,oid:oid_val,key:key},
				success:function(result) {
					console.log(result);
					// body...
					var a = result.split('::');
					//console.log(a);
				 	var test1 = a[0];
				 	var key = a[5];
					$('#datadisplayorg-'+key).html(test1);
					$('#orgcode-'+key).val(a[1]).change();
					$('#orgcombine-'+key).val(a[2]);
					$('#orgscore-'+key).val(a[3]).change();
					$('#oid-'+key).val(a[4]);
					$('#orgcode-'+key+' option[value="'+a[1]+'"]').attr("selected", "selected");
					$('#avg-'+key).html(a[6]);
				}
			});
		}
		//console.log(data_arr);
		// $('#orgcombine-'+key).val('');
		 //$('#orgcode-'+key).prop('selectedIndex',0);
		 //$('#orgscore-'+key).prop('selectedIndex',0);

	});
});

jQuery(function() {
	
pasportEnableDisable();
    jQuery("#edit-profile-main-field-nationality-und").change(function() {
		
		pasportEnableDisable();
    });
               academicreferenceEnableDisable();
    jQuery("#edit-profile-main-field-current-status-und").change(function() {
		
		academicreferenceEnableDisable();
    }); 

  jQuery("#user-profile-form").submit(function() {
         return validate_passport_number();	
    });
   
});
function validate_passport_number(){
pass_nub = jQuery('#edit-profile-main-field-passport-information-und-0-field-passport-number-und-0-value').val();
date_of_birth= jQuery('#edit-profile-main-field-passport-information-und-0-field-date-of-birth-und-0-value-datepicker-popup-0').val();
place_of_birth =jQuery('#edit-profile-main-field-passport-information-und-0-field-place-of-birth-und-0-value').val();
residential_address =jQuery('#edit-profile-main-field-passport-information-und-0-field-residential-address-line-1-und-0-value').val();
city_passport=jQuery('#edit-profile-main-field-passport-information-und-0-field-city-passport-und-0-value').val();
father_s_name=jQuery('#edit-profile-main-field-passport-information-und-0-field-father-s-name-und-0-value').val();
date_of_issue=jQuery('#edit-profile-main-field-passport-information-und-0-field-date-of-issue-und-0-value-datepicker-popup-0').val();
mother_s_name=jQuery('#edit-profile-main-field-passport-information-und-0-field-mother-s-name-und-0-value').val();
place_of_issue=jQuery('#edit-profile-main-field-passport-information-und-0-field-place-of-issue-und-0-value').val();
date_of_expiry=jQuery('#edit-profile-main-field-passport-information-und-0-field-date-of-expiry-und-0-value-datepicker-popup-0').val();

 //alert(pass_nub);
  //var flagval1 = jQuery('#edit-profile-main-field-institute-country-und option:selected').val();
  var flagval2 = jQuery('#edit-profile-main-field-nationality-und option:selected').val();

 if((flagval2 != 'IN') && (date_of_birth == '' || date_of_birth == null )){
   alert("Please enter date of birth.");
   return false;
  }
 else if((flagval2 != 'IN') && (place_of_birth == '' || place_of_birth == null )){
   alert("Please enter place of birth.");
   return false;
  }
/*else if((flagval1 != 'IN' || flagval2 != 'IN') && (residential_address == '' || residential_address == null )){
   alert("Please enter Residential address.");
   return false;
  }*/
else if((flagval2 != 'IN') && (city_passport == '' || city_passport == null )){
   alert("Please enter city passport.");
   return false;
  }
else if((flagval2 != 'IN') && (father_s_name == '' || father_s_name == null )){
   alert("Please enter father's name.");
   return false;
  }
else if((flagval2 != 'IN') && (mother_s_name == '' || mother_s_name == null )){
   alert("Please enter mother's name.");
   return false;
  }	
 else if((flagval2 != 'IN') && (pass_nub == '' || pass_nub == null )){
//alert ("Institute Country: "+ flagval1 + " Nationality: "+ flagval2);
   alert("Please enter passport number.");
   return false;
  }
else if((flagval2 != 'IN') && (date_of_issue == '' || date_of_issue == null )){
   alert("Please enter date of issue.");
   return false;
  }

else if((flagval2 != 'IN') && (place_of_issue == '' || place_of_issue == null )){
   alert("Please enter place of issue.");
   return false;
  }
else if((flagval2 != 'IN') && (date_of_expiry == '' || date_of_expiry == null )){
   alert("Please enter date of expiry.");
   return false;
  }

  //jQuery('#edit-profile-main-field-passport-information-und-0-field-passport-number-und-0-value').attr('value',"");
//faculty
  var currentstatus = '';
  currentstatus = jQuery('#edit-profile-main-field-current-status-und option:selected').val();
  
  var field_salutation = jQuery('#edit-profile-main-field-salutation-und option:selected').val();
  var field_referee_name = jQuery('#edit-profile-main-field-referee-name-und-0-value ').val();
  var field_affiliation_profile= jQuery('#edit-profile-main-field-affiliation-profile-und-0-value ').val();
  var field_email_id_referee = jQuery('#edit-profile-main-field-email-id-referee-und-0-value').val();
	if(currentstatus !='faculty' && (field_referee_name =='' || field_affiliation_profile == '' ||    field_email_id_referee == '')){
//	   alert("Please enter referee salutation, name, affiliation and email id.");
  //         return false;
	}
  return true;
}
function pasportEnableDisable(){
		var flagval1 = '';
		var flagval2 = '';
		//flagval1 = jQuery('#edit-profile-main-field-institute-country-und option:selected').val();
		flagval2 = jQuery('#edit-profile-main-field-nationality-und option:selected').val();
		
		if(flagval2 == 'IN'){
			//don't display
			jQuery('#edit-profile-main-field-passport-information').hide();
                        
		}
		else{
		       //display
			jQuery('#edit-profile-main-field-passport-information').show();
		}
}



function academicreferenceEnableDisable(){
		var flagval1 = '';
		var flagval2 = '';
        	flagval1 = jQuery('#edit-profile-main-field-current-status-und option:selected').val();
		//console.log(flagval1);
		//if(flagval1 == 'faculty' || flagval1 == 'postdoctoral' || flagval1 == 'student' || flagval1 == 'other'){
		if(flagval1 == 'faculty'){
			//don't display
			jQuery('.group-academic-information').hide();
                        jQuery('.group-references').hide();
                        
		}
		else{
			//display
			jQuery('.group-academic-information').show();
                        jQuery('.group-references').show();
		}

		if(flagval1 == 'postdoctoral' || flagval1 == 'student' || flagval1 == 'other'){
			//don't display
			jQuery('.group-references').hide();
                        
		}
		/*else{
			//display
			jQuery('.group-references').show();
		}**/
		if(flagval1 == 'faculty' || flagval1 == 'postdoctoral' || flagval1 == 'student' || flagval1 == 'other'){
			//don't display
			jQuery('#edit-profile-main-field-please-upload-your-cv').hide();
                    
		}
}

