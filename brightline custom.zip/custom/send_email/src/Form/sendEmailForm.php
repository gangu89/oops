<?php
/**
 * @file
 * Contains \Drupal\send_email\Form\HelloForm.
 */
namespace Drupal\send_email\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;

$base_path = Url::fromRoute('<front>', [], ['absolute' => TRUE])->toString();

class sendEmailForm extends FormBase {

    public function getFormId(){
        return 'send_email_form';
    }

    public function buildForm(array $form, FormStateInterface $form_state) {

        $form['email'] = array(
            '#type' => 'email',
            '#title' => $this->t('Email:'),
            '#title_display' => 'none',
            '#placeholder' => 'Email Address',
            '#pattern' => "^[a-zA-Z0-9](\.?[a-zA-Z0-9_]){0,}@[a-zA-Z0-9]+\.(?!-)([a-zA-Z0-9]?((-?[a-zA-Z0-9]+)+\.(?!-))){0,}[a-zA-Z]{2,8}$",
            '#required' => TRUE,
            '#attributes'=>array('class'=> array('b-round-2 transat-text-standard form-email required form-control'),'id' => array('send_mail_input')),
          );
          $form['user_role'] = array (
            '#type' => 'hidden',
            '#default' => 'user'
          );
          $form['timestamp'] = array (
            '#type' => 'hidden',
            '#default' => ''
          );
          $form['actions']['#type'] = 'actions';
          $form['actions']['submit'] = array(
            '#type' => 'submit',
            '#value' => $this->t('Sign up'),
            '#attributes'=>array('class'=> array('btn btn-dark h-100 b-round-2 text-uppercase transat-text-bold w-100 button js-form-submit form-submit btn btn-primary'), 'id' => array('send_mail_button')),
          );
          $form['#theme'] = 'send_email';
          return $form;
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {
        $values = array(
            'email' => $form_state->getValue('email'),
            'timestamp' => date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME'])
            );

            $insert = db_insert('send_email')
                    ->fields(
                       array(
                        'email' => $form_state->getValue('email'),
                        'role' => 'user',
                        'timestamp' => date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME'])
                 )
            )->execute();
          drupal_set_message(t('Form submitted.'));
       }

      public function validateForm(array &$form, FormStateInterface $form_state) {
        if (!$form_state->getValue('email') || !filter_var($form_state->getValue('email'), FILTER_VALIDATE_EMAIL)) {
          $form_state->setErrorByName('email', $this->t('Enter a valid email'));
        }
      }
}
