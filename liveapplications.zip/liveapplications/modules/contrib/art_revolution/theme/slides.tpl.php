<div<?php print $attributes;?>>
<div class="tp-banner" style="display:none; max-height:<?php print $settings->startheight;?>px; height:<?php print $settings->startheight;?>px;">
<ul>
<?php print $content;?>
</ul>
<?php if($settings->timer):?>
<div class="tp-bannertimer tp-<?php print $settings->timer;?>"></div>
<?php endif;?>
</div>
</div>
<?php
$slidesetting = new stdClass();
if($settings->delay) {
$slidesetting->delay = $settings->delay;
}
if($settings->startheight) {
$slidesetting->startheight = $settings->startheight;
}
if($settings->startwidth) {
	$slidesetting->startwidth = $settings->startwidth;
}
if($settings->hideThumbs) {
$slidesetting->hideThumbs = $settings->hideThumbs;
}
if($settings->thumbWidth) {
$slidesetting->thumbWidth = $settings->thumbWidth;
}
if($settings->thumbHeight) {
	$slidesetting->thumbHeight = $settings->thumbHeight;
}
if($settings->thumbAmount) {
	$slidesetting->thumbAmount = $settings->thumbAmount;
}
if($settings->navigationType) {
	$slidesetting->navigationType = $settings->navigationType;
}
if($settings->navigationArrows) {
	$slidesetting->navigationArrows = $settings->navigationArrows;
}
if($settings->navigationStyle) {
	$slidesetting->navigationStyle = $settings->navigationStyle;
}
if($settings->navigationHAlign) {
	$slidesetting->navigationHAlign = $settings->navigationHAlign;
}
if($settings->navigationVAlign) {
	$slidesetting->navigationVAlign = $settings->navigationVAlign;
}

$slidesetting->navigationHOffset = 0; //not done
$slidesetting->navigationVOffset = 20; //not done
$slidesetting->soloArrowLeftHalign = "left"; //not done
$slidesetting->soloArrowLeftValign = "center"; //not done
$slidesetting->soloArrowLeftHOffset = 0; //not done
$slidesetting->soloArrowLeftVOffset = 0; //not done
$slidesetting->soloArrowRightHalign = "right"; //not done
$slidesetting->soloArrowRightValign = "center"; //not done
$slidesetting->soloArrowRightHOffset = 0; //not done
$slidesetting->soloArrowRightVOffset = 0; //not done
$slidesetting->touchenabled = "on"; //not done
if(isset($settings->onHoverStop) && !empty($settings->onHoverStop)) {
	$slidesetting->onHoverStop = $settings->onHoverStop;
}
$slidesetting->stopAtSlide = -1; //not done
$slidesetting->stopAfterLoops = -1; //not done
$slidesetting->hideCaptionAtLimit = 0; //not done
$slidesetting->hideAllCaptionAtLilmit = 0; //not done
$slidesetting->hideSliderAtLimit = 0; //not done
if(isset($settings->shadow) && !empty($settings->shadow)) {
	$slidesetting->shadow = $settings->shadow;
}
if($settings->fullWidth) {
	$slidesetting->fullWidth = $settings->fullWidth;
}
if($settings->fullScreen) {
	$slidesetting->fullScreen = $settings->fullScreen;
}
if(isset($settings->fullScreenOffsetContainer) && !empty($settings->fullScreenOffsetContainer)) {
	$slidesetting->fullScreenOffsetContainer = $settings->fullScreenOffsetContainer;
}
$slidesetting->lazyLoad = 'on';
$slidesetting->soloArrowLeftHOffset =20;
$slidesetting->soloArrowRightHOffset =20;
if($settings->timer) {
	$slidesetting->timer =$settings->timer;
}
$slidesetting->shuffle = 'off';
if($settings->dottedOverlay) {
	$slidesetting->dottedOverlay = $settings->dottedOverlay;
}
$slidesetting = json_encode($slidesetting);
$js = "jQuery(document).ready(function($){if($.fn.cssOriginal!=undefined)$.fn.css = $.fn.cssOriginal;$('#{$id} .tp-banner').show().revolution({$slidesetting});})";
?>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
<?php print $js; ?>
//--><!]]>
</script>