<?php

namespace Drupal\taxonomy_tree\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;


/**
 * CountryForm controller.
 */
class CountryForm extends FormBase {

  /**
   * Returns a unique string identifying the form.
   *
   * The returned ID should be a unique string that can be a valid PHP function
   * name, since it's used in hook implementation names such as
   * hook_form_FORM_ID_alter().
   *
   * @return string
   *   The unique string identifying the form.
   */
  public function getFormId() {
    return 'taxonomy_tree_country_form';
  }

  /**
   * Form constructor.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The form structure.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['#theme'] = 'get_started';
    $tt = \Drupal::service('taxonomy_tree.taxonomy_term_tree');
    $tree = $tt->load('country');
    $country_tree['none'] = '---';
    $county = [];
    //$data .= "<option value='none'>---</option>";
    // $state_tree = [];
    // $state_tree[] = 'Choose A State';
    foreach ($tree as $tree_item) {
      
      $country_tree[$tree_item->tid] = $tree_item->name;
      
      //  echo '<pre>';print_r($Exclamation_Circle);exit;
      $county[] = $tree_item->tid;
      // if(!empty($tree_item->children)){

      //   foreach ($tree_item->children as $child_item){
      //     $state_tree[$child_item->tid] = ' -- ' . $child_item->name;
      //   }
      // }
    }
    //  echo '<pre>';print_r($county[0]);exit;
   $form['country_list'] = array(
      '#type' => 'select2',
      '#title' => 'Choose A State',
      // '#default_value' => $county[0],
      '#options' => $country_tree,      
      // '#title_display' => 'none',
      '#attributes' => ["id" => 'country_id',"class"=> "select-text"],     
  );

  //   $form['state_list'] = array(
  //     '#type' => 'select2',
  //     '#title' => 'Choose A Country',
  //     '#options' => [],     
  //     '#default_value' => '---',
  //     // '#title_display' => 'none',
  //     '#attributes' => ["id" => 'states_id',"class"=> "select-text"],
  // );
 
  $form['description'] = array(
    '#type' => 'textarea',
    '#title_display' => 'none',
    '#attributes' => ["id" => 'states_description','readonly' => 'readonly'],
    '#title' => 'Description',
  );

     return $form;

  }

  /**
   * Validate the title and the checkbox of the form.
   *
   * @param array $form
   *   The form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

 

  }

  /**
   * Form submission handler.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

   
  }

}
